#!/bin/sh -
# MiniBindFS shared library. Sourced by mount_bindfs / auto-bindfs / tests.
# Overridable: JBROOT ROOTFS CONFIG_PATH PLUTIL_CMD MOUNT_CMD BINDFSCTL (tests set these first)

: "${PLUTIL_CMD:=plutil}"
: "${MOUNT_CMD:=/sbin/mount}"
: "${BINDFSCTL:=/usr/libexec/mount_bindfs/bindfsctl}"
# root-owned config dir (vroot view of ${JBROOT}/Library/Preferences — not
# writable by mobile); the old /var/mobile/Library/Preferences location was a
# privilege boundary issue (mobile could control root mounts)
: "${CONFIG_PATH:=/Library/Preferences/com.dkxuanye.auto-bindfs.plist}"

# --- environment detection (roothide vs Dopamine/Relaxin) ---
# sets JBROOT (real path), ROOTFS ("/rootfs" on roothide, "" otherwise)
detect_env() {
    [ -n "${JBROOT}" ] && return 0
    if command -v jbroot >/dev/null 2>&1; then
        JBROOT="$(jbroot 2>/dev/null | sed 's#/$##')"
        ROOTFS="/rootfs"
    else
        JBROOT="/var/jb"
        ROOTFS=""
    fi
    [ -n "${JBROOT}" ]
}

# canonicalize user input path: absolute, no trailing slash, no /rootfs prefix,
# collapses '.' and '..' segments; returns '/' only for the root itself.
# Segment advancement uses FIXED patterns only — user-controlled segments are
# never used as glob patterns (avoids infinite loops on '[' '?' '*' etc).
canon_path() {
    _in="$1"
    case "${_in}" in
        /rootfs/*) _in="${_in#/rootfs}" ;;
        /*) ;;
        *) _in="/${_in}" ;;
    esac
    _abs=""
    _rest="${_in#/}"
    while [ -n "${_rest}" ]; do
        case "${_rest}" in
            */*)
                _seg="${_rest%%/*}"
                _rest="${_rest#*/}"
                ;;
            *)
                _seg="${_rest}"
                _rest=""
                ;;
        esac
        case "${_seg}" in
            ""|".") ;;
            "..") _abs="${_abs%/*}" ;;
            *) _abs="${_abs}/${_seg}" ;;
        esac
    done
    [ -n "${_abs}" ] || _abs="/"
    printf '%s\n' "${_abs}"
}

# --- config plist helpers (procursus plutil syntax, fake plutil in tests) ---
plist_create() { ${PLUTIL_CMD} -create "$1" >/dev/null 2>&1; }
plist_lint() { ${PLUTIL_CMD} -lint "$1" >/dev/null 2>&1; }
plist_set_bool() { ${PLUTIL_CMD} -key Enable -true "$1" >/dev/null 2>&1; }
plist_set_root() { ${PLUTIL_CMD} -key root -string "$2" "$1" >/dev/null 2>&1; }
plist_add_path() { ${PLUTIL_CMD} -key path -arrayadd -string "$2" "$1" >/dev/null 2>&1; }
plist_clear_paths() { ${PLUTIL_CMD} -remove -key path "$1" >/dev/null 2>&1; }
plist_path_arr_init() { ${PLUTIL_CMD} -key path -array "$1" >/dev/null 2>&1; }
plist_enabled() {
    _v="$(${PLUTIL_CMD} -key Enable "$1" 2>/dev/null)"
    [ "${_v}" = "true" ] || [ "${_v}" = "1" ]
}

# A config is trusted only when it was already protected before a privileged
# reader uses it. Support both BSD/macOS and GNU stat implementations.
config_is_trusted() {
    [ -f "$1" ] && [ ! -L "$1" ] || return 1
    _meta="$(stat -f '%u:%g:%Lp' "$1" 2>/dev/null)"
    if [ "${_meta}" = "0:0:600" ]; then
        return 0
    fi
    _meta="$(stat -c '%u:%g:%a' "$1" 2>/dev/null)" || return 1
    [ "${_meta}" = "0:0:600" ]
}

# A present configuration must be a regular file.  Check symlinks separately
# because -e is false for a dangling symlink on some BSD userlands.
config_path_is_invalid() {
    [ -L "$1" ] || { [ -e "$1" ] && [ ! -f "$1" ]; }
}

secure_config() {
    # Unit tests intentionally run unprivileged with a temporary config.
    [ "$(id -u)" = '0' ] || return 0
    [ -f "$1" ] && [ ! -L "$1" ] || return 1
    chown root:wheel "$1" 2>/dev/null && chmod 600 "$1" 2>/dev/null
}

# list configured paths, one per line; empty output when no path key
plist_paths() {
    _json="$(${PLUTIL_CMD} -showjson "$1" 2>&1)"
    case "${_json}" in
        "{\"path\":[\""*)
            _json="${_json#{\"path\":\[\"}"
            # strip from first array terminator '"],"' — works without an Enable
            # key and regardless of which keys follow path
            _json="${_json%%\"\],\"*}"
            printf '%s\n' "${_json}" | sed 's#","#\n#g'
            ;;
    esac
}

# --- mount state ---
# $1: canonical target path; matches the literal path, the real /private/var
# form, and the readlink-resolved real path (mount(8) prints the resolved
# form for symlinked mountpoints such as /var/jb -> /private/preboot/...)
# (fixed-string matching — paths with glob chars are matched literally)
is_bindfs_mounted() {
    _p="$1"
    _out="$(${MOUNT_CMD} 2>/dev/null)"
    _real="$(readlink -f "${_p}" 2>/dev/null)" || _real=''
    if [ -n "${_real}" ] && [ "${_real}" != "${_p}" ] && \
       printf '%s\n' "${_out}" | grep -Fq " on ${_real} (bindfs"; then
        return 0
    fi
    case "${_p}" in
        /var/*)
            if printf '%s\n' "${_out}" | grep -Fq " on /private${_p} (bindfs"; then
                return 0
            fi
            ;;
    esac
    printf '%s\n' "${_out}" | grep -Fq " on ${_p} (bindfs"
}

# --- copy logic ---
# $1: mode (0=if missing/empty, 1=force, 2=dir only) $2: real source $3: real dest
# file ops run on ${ROOTFS}-prefixed vroot-view paths (/rootfs in vroot env, "" otherwise)
ensure_copy() {
    _mode="$1" _src="$2" _dst="$3"
    _s="${ROOTFS}${_src}"
    _d="${ROOTFS}${_dst}"
    # refuse to rm -rf a copy target that is /, the source itself, inside the
    # source, or resolves to the same real path (readlink -f unavailable ->
    # both empty -> skip)
    _src_real="$(readlink -f "${_s}" 2>/dev/null)"
    _dst_real="$(readlink -f "${_d}" 2>/dev/null)"
    case "${_dst}" in
        "${_src}/"*|"${_src}") _inside_src='1' ;;
        *) _inside_src='0' ;;
    esac
    if [ "${_dst}" = "/" ] || [ "${_dst}" = "${_src}" ] || [ "${_inside_src}" = '1' ] || \
       { [ -n "${_src_real}" ] && [ -n "${_dst_real}" ] && [ "${_src_real}" = "${_dst_real}" ]; }; then
        echo "Error: refusing to copy onto itself: ${_dst}" >&2
        return 1
    fi
    case "${_mode}" in
        2)
            mkdir -p "${_d}"
            ;;
        1)
            mkdir -p "${_d}"
            rm -rf "${_d}"
            cp -a "${_s}" "${_d}"
            ;;
        0)
            if [ ! -d "${_d}" ] || [ -z "$(ls -A "${_d}" 2>/dev/null)" ]; then
                mkdir -p "${_d}"
                rm -rf "${_d}"
                cp -a "${_s}" "${_d}"
            fi
            ;;
    esac
}

# --- mount target root from config 'root' key ---
# $1: config plist path; prints real path.
# SECURITY: exact whitelist — only '.jbroot' or '.jbroot/bindfs' are accepted;
# anything else (incl. '.jbroot/..', '.jbroot/foo', absolute paths) falls back
# to the default so the mount source can never leave the jailbreak root.
resolve_mount_root() {
    _root="$(${PLUTIL_CMD} -key root "$1" 2>/dev/null)"
    case "${_root}" in
        .jbroot)
            printf '%s\n' "${JBROOT}"
            ;;
        .jbroot/bindfs)
            printf '%s\n' "${JBROOT}/bindfs"
            ;;
        *)
            printf '%s\n' "${JBROOT}/bindfs"
            ;;
    esac
}
